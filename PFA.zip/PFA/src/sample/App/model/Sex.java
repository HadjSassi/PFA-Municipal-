package sample.App.model;

public enum Sex {
    Homme,Femme,Autre
}
