package sample.App.model;

public enum Service {
    Administration,Ouvrier,terrain,direction
}
