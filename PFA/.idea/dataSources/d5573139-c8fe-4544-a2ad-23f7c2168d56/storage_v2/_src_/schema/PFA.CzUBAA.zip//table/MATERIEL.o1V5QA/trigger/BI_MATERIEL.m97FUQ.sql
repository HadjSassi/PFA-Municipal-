create trigger BI_MATERIEL
    before insert
    on MATERIEL
    for each row
begin
  if :NEW."ID" is null then
    select "MATERIELSEQ".nextval into :NEW."ID" from dual;
  end if;
end;
/

