create trigger BI_DEPENSE
    before insert
    on DEPENSE
    for each row
begin
  if :NEW."ID" is null then
    select "SEQDEPENSE".nextval into :NEW."ID" from dual;
  end if;
end;
/

