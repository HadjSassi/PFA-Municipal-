create trigger BI_DOLEANCE
    before insert
    on DOLEANCE
    for each row
begin   
  if :NEW."ID" is null then 
    select "MYSEQ".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

