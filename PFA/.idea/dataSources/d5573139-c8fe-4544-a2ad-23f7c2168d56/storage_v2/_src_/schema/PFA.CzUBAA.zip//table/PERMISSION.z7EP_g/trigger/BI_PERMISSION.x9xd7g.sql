create trigger BI_PERMISSION
    before insert
    on PERMISSION
    for each row
begin   
  if :NEW."ID" is null then 
    select "PERMISSIONSEQ".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

