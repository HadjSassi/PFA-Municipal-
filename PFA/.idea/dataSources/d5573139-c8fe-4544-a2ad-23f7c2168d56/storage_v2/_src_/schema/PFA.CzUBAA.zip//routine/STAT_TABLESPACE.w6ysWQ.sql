create function stat_tablespace (tbs IN varchar2)
return varchar2
is 
nb integer ;
free number ;
alou number;
used number;
pour number;
msg varchar2(30);
begin 
select count(tablespace_name) into nb from dba_data_files where tablespace_name = upper(tbs);
if nb = 0 then msg := 'le tablespace n existe pas';
else 
select bytes into free from dba_free_space where tablespace_name = upper(tbs) ;
select bytes into alou from dba_data_files where tablespace_name = upper(tbs) ;
free := free/(1024*2);
alou := alou/(1024*2);
used := alou-free;
pour := round((used/alou)*100,2);
msg := 'tablespace name : '||tbs||' =>espace alloué : '||alou||' MO, espace libre : '||free||' MO, espace utilisé : '||used||', pourcentage utilisé : '||pour||'%';
return msg;

end if;
end stat_tablespace;
/

