create procedure afficher_col_tables 
(nom_table IN all_tables.table_name%type)
is
nbr integer;
own varchar2(30);
cursor c is select * from all_tab_column where table_name = upper(nom_table);
cc c%rowtype;
begin
select COUNT(Table_name ) into nbr from all_tables where table_name = upper(nom_table );
if count = 0 then dbms_output.put_line("no data found");
elsif count >1 then dbms_output.put_line("too many rows");
else
select owner into own from all_tables where table_name = upper(nom_table);
dbms_output.put_line(own);
for cc in c loop
if cc.data_type = 'VARCHAR2' then dbms_output.put_line (cc.column_name||' '||cc.data_length);
elsif cc.data_type = 'NUMBER' then dbms_output.put_line (cc.column_name||' '||cc.data_precesion||' '||cc.data_scale);
elsif cc.data_type = 'DATE' then dbms_output.put_line(cc.column_name);
end if ;
end loop;
end if;
end afficher_col_tables ;
/

