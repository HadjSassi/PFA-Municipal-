create trigger BI_REVENU
    before insert
    on REVENU
    for each row
begin   
  if :NEW."ID" is null then 
    select "SEQREVENU".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

